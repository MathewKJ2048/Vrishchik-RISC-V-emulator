#!/bin/bash
function end()
{
    reap -p "Press any button to exit"
}
echo "loading..."
java -jar "Vrishchik.jar"
end
