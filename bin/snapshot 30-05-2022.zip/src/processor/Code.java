package processor;

public class Code {
    static void BubbleSort(){
        UTIL.StoreMem(0,10);
        UTIL.StoreMem(4,9);
        UTIL.StoreMem(8,8);
        UTIL.StoreMem(12,7);
        UTIL.StoreMem(16,6);
        UTIL.StoreMem(20,5);
        UTIL.StoreMem(24,33);
        UTIL.StoreMem(28,42);
        UTIL.StoreMem(32,-10);
        UTIL.StoreMem(36,3);
    }
}
